// FormView.cpp : implementation file
//

#include "stdafx.h"
#include "Analyzer.h"
#include "FormView.h"
#include ".\formview.h"


// FormView

IMPLEMENT_DYNCREATE(FormView, CFormView)

FormView::FormView()
	: CFormView(FormView::IDD)
	, m_dStartTime(0)
	, Num_Of_CheckName(0)
	, zoom_factor(1)
{
	FILE *ini;
	int index;
	char str[50];

	ini=fopen("config.ini","rt");
	index=0;

	while (!feof(ini) && (index<100))
	{
		fscanf(ini,"%s",Check_Name[index]);
		fscanf(ini,"%s",str);
		m_bCheckBox[index]=TRUE;
		index++;
	}

	for (int i=0;i<100;i++)
		IDC_CHECK[i]=2000+i;

	fclose(ini);
	Num_Of_CheckName=index;
}

FormView::~FormView()
{
}

void FormView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(FormView)
	for (int i=0;i<Num_Of_CheckName;i++)
		DDX_Check(pDX, IDC_CHECK[i], m_bCheckBox[i]);
	DDX_Text(pDX, IDC_ZoomFactor, zoom_factor);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(FormView, CFormView)
	ON_EN_CHANGE(IDC_EDIT1, OnChangeStartTime)
	ON_WM_CREATE()
	ON_BN_CLICKED(IDC_CHECK0, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK1, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK2, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK3, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK4, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK5, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK6, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK7, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK8, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK9, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK10, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK11, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK12, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK13, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK14, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK15, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK16, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK17, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK18, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK19, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK20, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK21, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK22, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK23, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK24, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK25, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK26, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK27, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK28, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK29, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK30, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK31, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK32, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK33, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK34, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK35, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK36, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK37, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK38, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK39, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK40, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK41, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK42, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK43, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK44, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK45, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK46, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK47, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK48, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK49, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK50, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK51, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK52, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK53, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK54, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK55, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK56, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK57, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK58, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK59, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK60, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK61, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK62, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK63, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK64, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK65, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK66, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK67, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK68, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK69, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK70, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK71, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK72, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK73, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK74, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK75, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK76, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK77, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK78, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK79, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK80, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK81, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK82, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK83, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK84, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK85, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK86, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK87, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK88, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK89, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK90, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK91, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK92, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK93, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK94, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK95, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK96, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK97, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK98, OnEnChange)
	ON_BN_CLICKED(IDC_CHECK99, OnEnChange)
	ON_EN_CHANGE(IDC_ZoomFactor, OnEnChangeZoomfactor)
	END_MESSAGE_MAP()


// FormView diagnostics

#ifdef _DEBUG
void FormView::AssertValid() const
{
	CFormView::AssertValid();
}

void FormView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG


// FormView message handlers

void FormView::OnEnChange()
{
	if (!UpdateData())
		return;

	UpdateData(TRUE);
	CAnalyzerDoc * pDoc = GetDocument();
	m_dStartTime = pDoc->m_dStartTime;
	for (int i=0;i<Num_Of_CheckName;i++)
		pDoc->m_bCheckBox[i]=m_bCheckBox[i];

	pDoc->zoom_factor=zoom_factor;
	pDoc->UpdateAllViews(this);
}

void FormView::OnChangeStartTime()
{
	if (!UpdateData())
		return;

	CAnalyzerDoc * pDoc = GetDocument();
	pDoc->m_dStartTime = m_dStartTime;
	pDoc->UpdateAllViews(this);
}

int FormView::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFormView::OnCreate(lpCreateStruct) == -1)
		return -1;

	int x,y,index;

	for (index=0;index<Num_Of_CheckName;index++)
	{
		x=10+160*(index%6);
		y=40+20*(index/6);
		pCheckBox[index] = new CButton;
		pCheckBox[index]->Create(Check_Name[index], WS_CHILD | WS_VISIBLE | BS_AUTOCHECKBOX, CRect(x, y, x+160, y+16), this, IDC_CHECK[index]);
	}
	return 0;
}

void FormView::OnEnChangeZoomfactor()
{
	if (!UpdateData())
		return;

	CAnalyzerDoc * pDoc = GetDocument();
	pDoc->zoom_factor = zoom_factor;
	pDoc->UpdateAllViews(this);
}

void FormView::OnDraw(CDC* /*pDC*/)
{
	CAnalyzerDoc * pDoc = GetDocument();
	UpdateData(TRUE);
	zoom_factor=pDoc->zoom_factor;
	this->m_dStartTime=pDoc->m_dStartTime;
	UpdateData(FALSE);
}
