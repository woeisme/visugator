// AnalyzerView.cpp : implementation of the CAnalyzerView class
//

#include "stdafx.h"
#include "Analyzer.h"

#include "AnalyzerDoc.h"
#include "AnalyzerView.h"
#include ".\analyzerview.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

CBrush GREY_Brush=RGB(200,200,200);
CBrush WHITE_Brush=RGB(255,255,255);


// CAnalyzerView

IMPLEMENT_DYNCREATE(CAnalyzerView, CView)

BEGIN_MESSAGE_MAP(CAnalyzerView, CView)
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
	ON_WM_HSCROLL()
	ON_WM_VSCROLL()
	ON_WM_SIZE()
	ON_WM_CREATE()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_WM_PAINT()
END_MESSAGE_MAP()

// CAnalyzerView construction/destruction

CAnalyzerView::CAnalyzerView()
: zoom_factor(1)
, zoom(false)
, HSCROLL(false)
, y_limit(0)
, y_start(0)
, mark(false)
, mark_time(0)
, current_time(0)
, start_time(0)
, end_time(0)
, mark_time2(0)
{
	MousePos.old_x=0;
	MousePos.old_y=0;
	MousePos.x1=0;
	MousePos.x2=0;
	MousePos.y1=0;
	MousePos.y2=0;
}

CAnalyzerView::~CAnalyzerView()
{
}

// CAnalyzerView drawing

void CAnalyzerView::OnDraw(CDC* pDC)
{
	EQueue::iterator temp;
	EventQueueStruct event;
	int width;
	int x1,y1,x2,y2;
	int y[255],height;
	CString str;

	CAnalyzerDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;

	if ((pDoc->loaded) )
	{
		CRect rect,rectUpdate;
		CFont font;
		VERIFY(font.CreateFont(
		14,                        // nHeight
		0,                         // nWidth
		0,                         // nEscapement
		0,                         // nOrientation
		FW_NORMAL,                 // nWeight
		FALSE,                     // bItalic
		FALSE,                     // bUnderline
		0,                         // cStrikeOut
		ANSI_CHARSET,              // nCharSet
		OUT_DEFAULT_PRECIS,        // nOutPrecision
		CLIP_DEFAULT_PRECIS,       // nClipPrecision
		DEFAULT_QUALITY,           // nQuality
		DEFAULT_PITCH | FF_SWISS,  // nPitchAndFamily
		"Microsoft Sans Serif"));                 // lpszFacename
		CPoint p;

		// Do something with the font just created...
		CFont* def_font = pDC->SelectObject(&font);
		pDC->SetTextAlign(TA_BASELINE);
		// Set Vertical Scroll & Horizontal Scroll
		GetClientRect(&rect);
		zoom_factor=pDoc->zoom_factor;
		this->SetScrollRange(SB_HORZ,0,(int)((pDoc->max_global_time-pDoc->min_globaltime)*zoom_factor-rect.right/2+50),TRUE);
		height=pDoc->NumOfStations*50+50;
		if (height>rect.bottom)
		{
			SetScrollRange(SB_VERT,0,pDoc->NumOfStations*50+50-rect.bottom-17,TRUE);
		}
		else
		{
			y_start=0;			
			SetScrollRange(SB_VERT,0,0,TRUE);
		}
		pDC->SetViewportOrg(0,-y_start);
		GetClientRect(rect);
		width=rect.right;
		start_time=pDoc->m_dStartTime;
		if (start_time < pDoc->min_globaltime)
			start_time=pDoc->min_globaltime;
		end_time=width/zoom_factor+start_time;

		// print Node Number
		for (int i=0;i<pDoc->NumOfStations;i++)
		{
			str.Format("Node %d:",i);
			y_limit=50+50*i;
			pDC->TextOut(1,y_limit,str);
			y[i]=36+50*i;
		}
		// Start to draw plots
		for (int i=0;i<pDoc->NumOfStations;i++)
		{
			for (int idx=0;idx<pDoc->History_Index_Count[i];idx++)
			{
				if ((pDoc->HistoryIndex[i][idx+1].globaltime>=start_time) && (pDoc->HistoryIndex[i][idx].globaltime<=start_time))
				{
					temp=pDoc->HistoryIndex[i][idx].index;
					event=*temp;
					break;
				}
				
			}
			y1=y[i];
			y2=(int)(y[i]+(int)(15));
			for (;((temp<pDoc->History[i].end())
				&& (event.mac_end<=end_time+2000));temp++)
			{
				event=*temp;
				if (((event.mac_end>=start_time) && (event.mac_end<=end_time)) ||
					((event.mac_start>=start_time) && (event.mac_start<=end_time)) ||
					((event.mac_start<=start_time) && (event.mac_end>=end_time)))
				{
					if (event.mac_start<start_time)
						x1=xstart;
					else
						x1=(int)((event.mac_start-start_time)*zoom_factor)+xstart;
					x2=(int)((event.mac_end-start_time)*zoom_factor)+xstart;
					if (x2>width) x2=width;
					if (pDoc->m_bCheckBox[event.mac_stat])
						pDC->SelectObject(&pDoc->MAC_Brush[event.mac_stat]);
					else
						pDC->SelectObject(&WHITE_Brush);
					pDC->Rectangle(CRect((int)x1,y1,(int)x2,y2));
				}
			}
		}
		
		// Draw Time Mark
		if (mark && (mark_time>=start_time) && (mark_time<=end_time))
		{
			p.x=(int)((mark_time-start_time)*zoom_factor)+xstart;
			p.y=20;
			pDC->MoveTo(p);
			p.y=y_limit+50;
			pDC->LineTo(p);
		}

		// Draw Time Mark 2 for Zoom
		if (zoom && (mark_time2>=start_time) && (mark_time2<=end_time))
		{
			p.x=(int)((mark_time2-start_time)*zoom_factor)+xstart;
			p.y=20;
			pDC->MoveTo(p);
			p.y=y_limit+50;
			pDC->LineTo(p);
		}
		// Draw Current Time Mark
		if ((MousePos.old_x>=xstart) && (MousePos.old_x<=rect.right))
		{
			p.y=20;
			p.x=MousePos.old_x;
			pDC->MoveTo(p);
			p.y=y_limit+50;
			pDC->LineTo(p);
		}

		CPoint pt(1,11);
		pDC->DPtoLP(&pt);
		str.Format("Current Time:%013.2f us Marked Time: %013.2f Display Range:%013.2f us - %013.2f us",current_time,mark_time,start_time,end_time);
		pDC->TextOut(pt.x, pt.y,	str);
		// Done with the font.  Delete the font object.
		pDC->SelectObject(def_font);
		font.DeleteObject();

	}
}

// CAnalyzerView printing

BOOL CAnalyzerView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CAnalyzerView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CAnalyzerView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}


// CAnalyzerView diagnostics

#ifdef _DEBUG
void CAnalyzerView::AssertValid() const
{
	CView::AssertValid();
}

void CAnalyzerView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CAnalyzerDoc* CAnalyzerView::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CAnalyzerDoc)));
	return (CAnalyzerDoc*)m_pDocument;
}
#endif //_DEBUG


// CAnalyzerView message handlers

void CAnalyzerView::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	CAnalyzerDoc* pDoc = GetDocument();
	
	if (pDoc->loaded)
	{
		int max_pos,current_pos;
		CRect rect;
		double start_time;
		SCROLLINFO info;
		
		info.cbSize = sizeof(SCROLLINFO);
		info.fMask = SIF_TRACKPOS;

		GetScrollInfo(SB_HORZ,&info);
		nPos = info.nTrackPos;

		zoom=false;
		HSCROLL=true;
		max_pos = this->GetScrollLimit(SB_HORZ);
		GetClientRect(&rect);
		if (pDoc->m_dStartTime<pDoc->min_globaltime)
			pDoc->m_dStartTime=pDoc->min_globaltime;
		start_time=pDoc->m_dStartTime;
		current_pos=GetScrollPos(SB_HORZ);
		switch(nSBCode) 
		{
		case SB_LEFT:
			start_time=pDoc->min_globaltime;
			current_pos=(int)((start_time-pDoc->min_globaltime));
			break;
		case SB_RIGHT:
			start_time=pDoc->max_global_time/zoom_factor-rect.right/2+50;
			current_pos=(int)((start_time-pDoc->min_globaltime));
			break;
		case SB_LINELEFT: // left arrow button
			//start_time=pDoc->m_dStartTime-(25/zoom_factor);
			//if (start_time<pDoc->min_globaltime) start_time=pDoc->min_globaltime;
			//current_pos=(int)((start_time-pDoc->min_globaltime));
			current_pos-=25;
			break;
		case SB_LINERIGHT: // right arrow button
			//start_time=pDoc->m_dStartTime+(25/zoom_factor);
			//if (start_time>pDoc->max_global_time-((rect.right-10)*zoom_factor))
			//	start_time=pDoc->max_global_time-(rect.right-10)*zoom_factor;
			//current_pos=(int)((start_time-pDoc->min_globaltime));
			current_pos+=25;
			break;
		case SB_PAGELEFT:
			//start_time=pDoc->m_dStartTime-((rect.right-xstart)/2)/zoom_factor;
			//if (start_time<pDoc->min_globaltime) start_time=pDoc->min_globaltime;
			//current_pos=(int)((start_time-pDoc->min_globaltime));
			current_pos-=rect.right/2;
			break;
		case SB_PAGERIGHT:
			//start_time=pDoc->m_dStartTime+((rect.right-xstart)/2)/zoom_factor;
			//if (start_time>pDoc->max_global_time-((rect.right-xstart)/2*zoom_factor))
			//	start_time=pDoc->max_global_time-((rect.right-xstart)/2*zoom_factor);
			//current_pos=(int)((start_time-pDoc->min_globaltime));
			current_pos+=rect.right/2;
			break;
		case SB_THUMBPOSITION:
		case SB_THUMBTRACK:
			current_pos=nPos;
			break;
		} 
		if (current_pos<0) current_pos=0;
		if (current_pos>info.nMax) current_pos=info.nMax;
		SetScrollPos(SB_HORZ,current_pos,TRUE);
		start_time=(current_pos/zoom_factor-rect.right/2+50)+pDoc->min_globaltime;
		pDoc->m_dStartTime=start_time;
		Invalidate();
		zoom=false;
		
	}
	else
		CAnalyzerView::OnHScroll(nSBCode, nPos, pScrollBar);
}

void CAnalyzerView::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	CAnalyzerDoc* pDoc = GetDocument();

	if (pDoc->loaded)
	{
		CRect rect;
		int current_pos;
		int max_y;

		GetClientRect(&rect);
		current_pos=GetScrollPos(SB_VERT);
		max_y=y_limit-rect.bottom+50;
		switch(nSBCode) 
		{
		case SB_TOP:
			y_start=0;
			current_pos=0;
			break;
		case SB_BOTTOM:
			y_start=max_y;
			current_pos=y_start;
			break;
		case SB_LINEDOWN: // down arrow button
			y_start+=10;
			if (y_start>max_y)
				y_start=max_y;
			current_pos=y_start;
			break;
		case SB_LINEUP: // up arrow button
			y_start-=10;
			if (y_start<0) y_start=0;
			current_pos=y_start;
			break;
		case SB_PAGEDOWN:
			y_start+=(rect.bottom-260);
			if (y_start>max_y)
				y_start=max_y;
			current_pos=y_start;
			break;
		case SB_PAGEUP:
			y_start-=(rect.bottom-260);
			if (y_start<0)
				y_start=0;
			current_pos=y_start;
			break;
		case SB_THUMBPOSITION:
		case SB_THUMBTRACK:
			current_pos=nPos;
			y_start=nPos;
			break;
		} 

		SetScrollPos(SB_VERT,current_pos,TRUE);
		Invalidate();
		zoom=false;
	}
	else
		CAnalyzerView::OnVScroll(nSBCode, nPos, pScrollBar);
}



void CAnalyzerView::OnSize(UINT nType, int cx, int cy)
{
	CView::OnSize(nType, cx, cy);

	//CRect rect;
	//GetClientRect(&rect);
	//m_ScrollBar.SetWindowPos( &(CWnd::wndTop) , rect.left, rect.bottom-16, rect.right-rect.left, 16, SWP_NOZORDER);
}

int CAnalyzerView::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;
	return 0;
}
void CAnalyzerView::OnLButtonDown(UINT nFlags, CPoint point)
{
	CString str;
	CAnalyzerDoc* pDoc = GetDocument();
	if (pDoc->loaded)
	{
		CRect rect;
		CDC *pDC=GetDC();
		pDC->SetViewportOrg(0,-y_start);
		if (!zoom)
		{
			// Clear old mark
			if (mark && (mark_time>=start_time) && (mark_time<=end_time))
			{
				rect.left=(int)((mark_time-start_time)*zoom_factor)+xstart-1;
				rect.right=rect.left+2;
				rect.top=20;
				rect.bottom=y_limit+50;
				pDC->LPtoDP(rect);
				InvalidateRect(rect,TRUE);
			}

			MousePos.x1=point.x;
			MousePos.y1=point.y;
			MousePos.x2=MousePos.x1;
			MousePos.y2=MousePos.y1;
			mark=true;
			mark_time=((float)(MousePos.x1-xstart)/zoom_factor)+start_time;			
			SetCapture();
			::SetCursor(::LoadCursor(NULL, IDC_CROSS));
		}
		else
		{
			mark=false;
			if (MousePos.x1<MousePos.x2)
			{
				// Zoom In
				if ((point.x>=MousePos.x1) && (point.x<=MousePos.x2))
				{
					zoom_factor=zoom_factor*(end_time-start_time)/(mark_time2-mark_time);
				}
				else // Zoom Out
				{
					zoom_factor=zoom_factor*(mark_time2-mark_time)/(end_time-start_time);
				}
				start_time=mark_time;
			}
			else
			{
				// Zoom In
				if ((point.x>=MousePos.x2) && (point.x<=MousePos.x1))
				{
					zoom_factor=zoom_factor*(end_time-start_time)/(mark_time-mark_time2);
				}
				else // Zoom Out
				{
					zoom_factor=zoom_factor*(mark_time-mark_time2)/(end_time-start_time);
				}
				start_time=mark_time2;
			}
			if (zoom_factor>100)
				zoom_factor=100;
			else if (zoom_factor<0.001)
				zoom_factor=0.001;
			pDoc->m_dStartTime=start_time;
			pDoc->zoom_factor=zoom_factor;
			this->GetClientRect(&rect);
			SetScrollRange(SB_HORZ,0,(int)((pDoc->max_global_time-pDoc->min_globaltime)*zoom_factor-rect.right/2+50),TRUE);
			SCROLLINFO info;
			int current_pos;
			GetScrollInfo(SB_HORZ,&info);
			if (pDoc->m_dStartTime<pDoc->min_globaltime)
				pDoc->m_dStartTime=pDoc->min_globaltime;
			current_pos=(int)((start_time-pDoc->min_globaltime));
			SetScrollPos(SB_HORZ,current_pos,TRUE);
			Invalidate();
			this->UpdateWindow();
			pDoc->UpdateAllViews(NULL);
		}
	}
	CView::OnLButtonDown(nFlags, point);
}

void CAnalyzerView::OnLButtonUp(UINT nFlags, CPoint point)
{
	CAnalyzerDoc* pDoc = GetDocument();
	CRect clip_rect;

	if (pDoc->loaded)
	{
		CRect rect;
		CDC *pDC=GetDC();
		::ReleaseCapture();
		if (!zoom)
		{
			MousePos.x2=point.x;
			MousePos.y2=point.y;
			if (abs(MousePos.x1-MousePos.x2)<5)
			{
				zoom=false;
				mark=true;
				mark_time=((float)(MousePos.x1-xstart)/zoom_factor)+start_time;
				pDC->SetViewportOrg(0,-y_start);
		
				// Update Current Time
				clip_rect.bottom=13;
				clip_rect.right=300;
				clip_rect.top=0;
				clip_rect.left=220;
				//pDC->LPtoDP(clip_rect);
				InvalidateRect(clip_rect,FALSE);

			}
			else
			{
				zoom=true;
				mark_time2=((float)(MousePos.x2-xstart)/zoom_factor)+start_time;
			}
		}
		else
		{
			zoom=false;
			mark_time=0;
			mark_time2=0;
		}
	}
}

void CAnalyzerView::OnMouseMove(UINT nFlags, CPoint point)
{
	CString str;
	CAnalyzerDoc* pDoc = GetDocument();
	CRect rect,clip_rect;
	CRect rect3;
	CPoint p;

	GetClientRect(&rect);
	current_time=((float)(point.x-xstart)/zoom_factor)+start_time;
	if ((pDoc->loaded) && (current_time>=start_time) && (current_time<=end_time))
	{
		CDC *pDC=GetDC();
		pDC->SetViewportOrg(0,-y_start);
		
		// Update Current Time
		clip_rect.bottom=13;
		clip_rect.right=140;
		clip_rect.top=0;
		clip_rect.left=64;
		//pDC->LPtoDP(clip_rect);
		InvalidateRect(clip_rect,FALSE);

		// Remove old cursor
		clip_rect.bottom=y_limit+50;
		clip_rect.right=MousePos.old_x+1;
		clip_rect.left=MousePos.old_x-1;
		clip_rect.top=14;
//		pDC->LPtoDP(clip_rect);
		InvalidateRect(clip_rect,TRUE);

		// Draw new cursor
		MousePos.old_x=point.x;
		MousePos.old_y=point.y;
		clip_rect.bottom=y_limit+50;
		clip_rect.right=MousePos.old_x+1;
		clip_rect.left=MousePos.old_x-1;
		clip_rect.top=14;
//		pDC->LPtoDP(clip_rect);
		InvalidateRect(clip_rect,TRUE);
	}
}
