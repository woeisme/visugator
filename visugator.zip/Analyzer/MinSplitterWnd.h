#if !defined(AFX_MINSPLITTERWND_H__4CC0B23A_14EC_11D2_8500_444553540000__INCLUDED_)
#define AFX_MINSPLITTERWND_H__4CC0B23A_14EC_11D2_8500_444553540000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// SplitterWnd2.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CMinSplitterWnd window

class CMinSplitterWnd : public CSplitterWnd
{
// Construction
public:
	CMinSplitterWnd();

// Attributes
public:
	int		GetMinClientWidth();		//	For resizing.
	int		GetMinClientHeight();

// Operations
public:
	virtual void RecalcLayout();    // call after changing sizes

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMinSplitterWnd)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMinSplitterWnd();

	// Generated message map functions
protected:
	//{{AFX_MSG(CMinSplitterWnd)
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnWindowPosChanging(WINDOWPOS FAR* lpwndpos);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MINSPLITTERWND_H__4CC0B23A_14EC_11D2_8500_444553540000__INCLUDED_)
