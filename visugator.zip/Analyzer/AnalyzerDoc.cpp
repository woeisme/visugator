// AnalyzerDoc.cpp : implementation of the CAnalyzerDoc class
//

#include "stdafx.h"
#include "Analyzer.h"

#include "AnalyzerDoc.h"
#include ".\analyzerdoc.h"
#include <deque>
#include <stdio.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CAnalyzerDoc

IMPLEMENT_DYNCREATE(CAnalyzerDoc, CDocument)

BEGIN_MESSAGE_MAP(CAnalyzerDoc, CDocument)
	ON_COMMAND(ID_FILE_OPEN, OnFileOpen)
END_MESSAGE_MAP()


// CAnalyzerDoc construction/destruction

CAnalyzerDoc::CAnalyzerDoc()
: loaded(false)
, File_Name(_T(""))
, min_globaltime(0)
, max_global_time(0)
, m_dStartTime(0)
, NumOfStations(0)
, zoom_factor(1)
{
	FILE *ini;
	int index;
	CString str;
	char input[100];
	TOKENQUEUE::iterator token;
	int Color[3];

	ini=fopen("config.ini","rt");
	index=0;

	while (!feof(ini) && (index<100))
	{
		fscanf(ini,"%s",Check_Name[index]);
		fscanf(ini,"%s",input);
		parse(input);
		token=token_queue.begin();
		for (int i=0;i<3;i++,token++)
		{
			str=*token;
			Color[i]=atoi(str);
		}
		MAC_Brush[index].CreateSolidBrush(RGB(Color[0],Color[1],Color[2]));
		m_bCheckBox[index]=true;
		index++;
	}

	fclose(ini);
	Num_Of_CheckName=index;
	this->UpdateAllViews(NULL);
}

CAnalyzerDoc::~CAnalyzerDoc()
{
}

BOOL CAnalyzerDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}

// CAnalyzerDoc serialization

void CAnalyzerDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}


// CAnalyzerDoc diagnostics

#ifdef _DEBUG
void CAnalyzerDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CAnalyzerDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG


// CAnalyzerDoc commands

void CAnalyzerDoc::OnFileOpen()
{
	CString str;
	int str_len,index;
	FILE *in;
	char input[6000];
	double globaltime,prev_globaltime;
	EventQueueStruct event;
	EQueue::iterator temp;
	TOKENQUEUE::iterator token;
	int prev_mac[255];
	double prev_starttime[255];
	int i;
	
	CFileDialog dlg2(TRUE,"*","*.csv");
	if (dlg2.DoModal()==IDOK)
	{
		index=0;
		str_len=dlg2.GetPathName().GetLength();
		
		File_Name=dlg2.GetPathName();
		for (i=0;i<str_len;i++)
			filename[i]=dlg2.GetPathName().GetAt(i);
		filename[i]=0;
		
		if (strlen(filename)!=0)
		{
			in=fopen(filename,"r");
			loaded=true;
			
			NumOfStations=parse_columns(in)-1;
			// Clear History
			for (i=0;i<NumOfStations;i++)
				History[i].clear();
			// Support up to 255 stations
			for (i=0;i<NumOfStations;i++)
			{
				prev_mac[i]=0;
				prev_starttime[i]=0;
			}
			min_globaltime=1e30;
			globaltime=0;
			max_global_time=0;
			m_dStartTime=0;
			
			while (!feof(in))
			{
				// Parse Time
				prev_globaltime=globaltime;
				fscanf(in,"%s",input);
				parse(input);
				token=token_queue.begin();
				str=*token;
				globaltime=atof(str);
				// If no more valid data, then quit
				if (globaltime<prev_globaltime)
					break;
				if (globaltime>max_global_time)
					max_global_time=globaltime;
				else
					if (globaltime<min_globaltime)
						min_globaltime=globaltime;
				index=0;
				while(index<NumOfStations)
				{	
					token++;
					str=*token;
					if (str!="")
					{
						// parse MAC status
						event.mac_stat=prev_mac[index];
						event.mac_start=prev_starttime[index];
						event.mac_end=globaltime;
						History[index].push_back(event);
						//int Array_Size=sizeof MACstateSTR/sizeof MACstateSTR[0];
						for (i=0;i<Num_Of_CheckName;i++)
						{
							if (str==Check_Name[i])
							{
								prev_mac[index]=i;
								break;
							}
						}
						prev_starttime[index]=globaltime;
					}
					index++;
				}
				m_dStartTime=globaltime;
			}
			loaded=true;
			m_dStartTime=min_globaltime;
			UpdateAllViews(NULL);
			fclose(in);

			// Initialize fast reference index
			double prev_time[255];
			int h_index;

			for (i=0;i<NumOfStations;i++)
			{
				for (int j=0;j<1000;j++)
					HistoryIndex[i][j].globaltime=1e36;
				prev_time[i]=0;
				h_index=0;

				temp=History[i].begin();
				HistoryIndex[i][h_index].index=temp;
				event=*temp;
				HistoryIndex[i][h_index].globaltime=event.mac_start;
				History_Index_Count[i]=1;
				for (temp=History[i].begin();temp<History[i].end();temp++)
				{
					event=*temp;
					if (event.mac_start-prev_time[i]>=10000)
					{
						h_index++;
						History_Index_Count[i]++;
						HistoryIndex[i][h_index].index=temp;
						prev_time[i]=event.mac_start;
						HistoryIndex[i][h_index].globaltime=event.mac_start;
					}
				}
			}
		}
		this->UpdateAllViews(NULL);
	}
}

int CAnalyzerDoc::parse_columns(FILE *in)
{
	char c[1];
	bool done=false;
	int n=0;

	while((!done) && (!feof(in)))
	{
		fread(c,1,1,in);
		if (c[0]==10)
		{
			done=true;
		}
		if (c[0]==',')
			n++;
	}
	return n;
}

void CAnalyzerDoc::parse(char str[])
{
	bool done;
	int i,j,len;
	CString cs;

	
	done=false;
	i=0;
	len=(int)strlen(str);
	if (!token_queue.empty())
		token_queue.clear();
	j=0;
	cs.Empty();
	for (i=0;i<=len;i++)
	{
		if ((str[i]==10) || (str[i]==0) || (str[i]==9) || (str[i]==13) || (str[i]==',') || (str[i]==' '))
		{
			cs+=(char)0x0;
			if (!cs.IsEmpty())
				cs.MakeUpper();
			token_queue.push_back(cs);
			cs.Empty();
		}
		else
			cs+=str[i];
	}

}

