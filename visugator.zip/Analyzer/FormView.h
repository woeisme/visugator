#pragma once
#include "AnalyzerDoc.h"


// FormView form view

class FormView : public CFormView
{
	DECLARE_DYNCREATE(FormView)

protected:
	FormView();           // protected constructor used by dynamic creation
	virtual ~FormView();

public:
	enum { IDD = IDD_FORMVIEW };
	CAnalyzerDoc* GetDocument()
	{
		ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CAnalyzerDoc)));
		return (CAnalyzerDoc*) m_pDocument;
	}

#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	double m_dStartTime;
	int Num_Of_CheckName;
	char Check_Name[100][50];
	CButton *pCheckBox[100];
	int IDC_CHECK[100];
	BOOL m_bCheckBox[100];
	afx_msg void OnEnChange();
	afx_msg void OnChangeStartTime();
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	double zoom_factor;
	afx_msg void OnEnChangeZoomfactor();
protected:
	virtual void OnDraw(CDC* /*pDC*/);
};


