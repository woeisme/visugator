// AnalyzerView.h : interface of the CAnalyzerView class
//


#pragma once
#include "afxwin.h"

#define xstart 50

class CAnalyzerView : public CView
{
protected: // create from serialization only
	CAnalyzerView();
	DECLARE_DYNCREATE(CAnalyzerView)

// Attributes
public:
	CAnalyzerDoc* GetDocument() const;

// Operations
public:

// Overrides
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);

// Implementation
public:
	virtual ~CAnalyzerView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	double zoom_factor;
	tagInvalidateArea InvalidateArea;
	tagMousePos MousePos;
	bool zoom;
	bool HSCROLL;
	afx_msg void OnSize(UINT nType, int cx, int cy);
	CScrollBar m_ScrollBar;
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	//virtual BOOL OnScroll(UINT nScrollCode, UINT nPos, BOOL bDoScroll = TRUE);
	int y_limit;
	int y_start;
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	bool mark;
	double mark_time;
public:
	double current_time;
	double start_time;
	double end_time;
	double mark_time2;
};

#ifndef _DEBUG  // debug version in AnalyzerView.cpp
inline CAnalyzerDoc* CAnalyzerView::GetDocument() const
   { return reinterpret_cast<CAnalyzerDoc*>(m_pDocument); }
#endif

