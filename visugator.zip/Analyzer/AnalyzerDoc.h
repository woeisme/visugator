// AnalyzerDoc.h : interface of the CAnalyzerDoc class
//

#include <deque>

#pragma once

typedef struct tagEventQueueStruct
{
	int mac_stat;
	double mac_start;
	double mac_end;
} EventQueueStruct;

using namespace std;
typedef deque<EventQueueStruct >  EQueue;

typedef deque<CString>  TOKENQUEUE;

struct tagHistoryIndex
{
	EQueue::iterator index;
	double globaltime;
};

struct tagInvalidateArea
{
	int x1; // top left x position
	int y1; // top left y position
	int x2; // bottom right x position
	int y2; // bottom right y position
};

struct tagMousePos
{
	int x1; // top left x position
	int y1; // top left y position
	int x2; // bottom right x position
	int y2; // bottom right y position
	int old_x;
	int old_y;
};

class CAnalyzerDoc : public CDocument
{
protected: // create from serialization only
	CAnalyzerDoc();
	DECLARE_DYNCREATE(CAnalyzerDoc)

// Attributes
public:

// Operations
public:

// Overrides
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);

// Implementation
public:
	virtual ~CAnalyzerDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnFileOpen();
	bool loaded;
	CString File_Name;
	double min_globaltime;
	double max_global_time;
	double m_dStartTime;
	int NumOfStations;
	int parse_columns(FILE *in);
	void parse(char str[]);
	char filename[255];
	EQueue History[255];
	char Check_Name[100][50];
	int Num_Of_CheckName;
	BOOL m_bCheckBox[100];
	CBrush MAC_Brush[100];

	TOKENQUEUE token_queue;
	int History_Index_Count[255];
	tagHistoryIndex HistoryIndex[255][1000];
	double zoom_factor;
};


